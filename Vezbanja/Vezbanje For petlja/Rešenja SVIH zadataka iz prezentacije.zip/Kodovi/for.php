<?php	
	/*
		1. Ispisati brojeve od 1 do 20
	*/
	/*
	for($i=1; $i<=20; $i++)
	{
		echo $i;
		echo "<br>";
	}
	*/
	
	/*
		2. Ispisati brojeve od 20 do 1
	*/
	/*
	for($i=20; $i>=1; $i--)
	{
		echo $i;
		echo "<br>";
	}
	*/
	
	/*
		3. Ispisati perne brojeve
		od 1 do 20
	*/
	/*
	for($i=1; $i<=20; $i++)
	{
		if($i%2 == 0)
		{
			echo $i;
			echo "<br>";
		}
	}
	*/
	/*
	for($i=2; $i<=20; $i+=2)
	{
		echo $i;
		echo "<br>";
	}
	*/
	
	/*
		5. Ispisati dvostruku 
		vrednost brojeva od 5 do 15
	*/
	/*
	for($i=5; $i<=15; $i++)
	{
		echo "<p>". 2*$i ."</p>";
		echo "<br>";
	}
	*/
	
	/*
		6. Suma brojeva od 1 do n
	*/
	/*
	$s = 0;
	$n = 5;
	
	for($i=1; $i<=$n; $i++)
	{
		//$s = $s + $i;
		$s += $i;
	}
	echo $s;
	echo "<br>";
	*/
	
	/*
		7. Suma brojeva od n do m
	*/
	/*
	$s = 0;
	$n = 5;
	$m = 7;
	
	for($i=$n; $i<=$m; $i++)
	{
		//$s = $s + $i;
		$s += $i;
	}
	echo $s;
	echo "<br>";
	*/
	
	/*
		8. Proizvod brojeva od n do m
	*/
	/*
	$n = 1;
	$m = 5;
	$p = 1;
	
	for($i=$n; $i<=$m; $i++)
	{
		//$p = $p * $i;
		$p *= $i;
	}
	echo $p;
	echo "<br>";
	*/
	
	/*
		9. Suma kvadrata brojeva 
		od n do m
	*/
	/*
	$n = 1;
	$m = 5;
	$s = 0;
	
	for($i=$n; $i<=$m; $i++)
	{
		$s = $s + $i*$i;
		//$s += $i*$i;
	}
	echo $s;
	echo "<br>";
	*/
	
	/*
		11. Sabrati sve brojeve 
		deljive sa 9
		u intervalu od 1 do 30.

	*/
	/*
	$s = 0;
	for($i=1; $i<=30; $i++)
	{
		if ($i%9 == 0)
		{
			$s += $i;
			//$s = $s + $i;
		}
	}
	echo $s;
	echo "<br>";
	*/
	
	/*
		12. Odrediti proizvod 
		svih brojeva deljivih 
		sa 11 u intervalu 
		od 20 do 100.
	*/
	/*
	$p = 1;
	for($i=20; $i<=100; $i++)
	{
		if ($i%11 == 0)
		{
			$p *= $i;
			//$p = $p * $i;
		}
	}
	echo $p;
	echo "<br>";
	*/
	
	
	/*
for($i=1; $i<=3; $i++)
{
	echo "<img src='$i.png'>";
	echo "<br>";
}
*/

/*
13. Zadatak
Prebrojati koliko ima brojeva deljivih sa 13 
u intervalu od 5 do 150
*/
/*
$br = 0;
for($i=5; $i<=150; $i++)
{
	if($i%13 == 0)
	{
		$br += 1;
		//$br = $br + 1;
		//$br++;
	}
}
echo $br;
*/

/*
14. Zadatak
Ispisati aritmetičku sredinu 
brojeva od n do m
*/
/*
$n = 5;
$m = 15;
$sum = 0;
$br = 0;
for($i=$n; $i<=$m; $i++)
{
	$sum += $i;
	$br += 1;
}
$sr = $sum / $br;
echo $sr;
echo "<br>";

$br1 = $m - $n + 1; 
$sr1 = $sum / $br1;
echo $sr1;
echo "<br>";
*/

/*
15. Zadatak
Prebrojati koliko brojeva od n do m je pozitivno, 
a koliko njih je negativno.
*/
/*
$n = -5;
$m = 5;
$neg = 0;
$poz = 0;
for($i=$n; $i<=$m; $i++)
{
	if($i >= 0)
	{
		$poz++;
	}
	else
	{
		$neg++;
	}
}
echo "Pozitivni su: $poz <br>";
echo "Negativni su: $neg";
*/

/*
16. Zadatak
Prebrojati koliko je brojeva
od 5 do 50 koji su deljivi 
sa 3 ili sa 5.
*/
/*
$brDeljivih = 0;
for($i=5; $i<=50; $i++)
{
	if($i%3==0 or $i%5==0)
	{
		$brDeljivih++;
	}
}
echo $brDeljivih;
*/

/*
17. Zadatak
Prebrojati i izračunati 
sumu brojeva od n do m 
kojima je poslednja cifra 
4 i parni su.
*/
/*
$n = 10;
$m = 30;
$sum = 0;
$br = 0;
for($i=$n; $i<=$m; $i++)
{
	$pos = $i%10;
	if($pos == 4)
	{
		$sum += $i;
		$br++;
	}
}
echo "Suma je: $sum, broj je $br";
*/

/*
18. Zadatak
Ispisati brojeve od n do m, 
koji su deljivi sa a.
*/
/*
$n = 5;
$m = 10;
$a = 5;
for($i=$n; $i<=$m; $i++)
{
	if($i%$a == 0)
	{
		echo "<p> $i </p>";
	}
}
*/

/*
19. Zadatak
Ispisati brojeve od n do m, 
koji nisu deljivi sa a.
*/
/*
$n = 5;
$m = 10;
$a = 5;
for($i=$n; $i<=$m; $i++)
{
	if($i%$a != 0)
	{
		echo "<p> $i </p>";
	}
}
*/

/*
20. Zadatak
Ispisati brojeve od n do m, 
koji su deljivi sa a.
*/
/*
$n = 5;
$m = 10;
$a = 5;
$sum = 0;
for($i=$n; $i<=$m; $i++)
{
	if($i%$a != 0)
	{
		$sum += $i;
	}
}
echo $sum;
*/

/*
21. Zadatak
Ispisati brojeve od n do m, 
koji su deljivi sa a.
*/
/*
$n = 5;
$m = 10;
$a = 5;
$pro = 1;
for($i=$n; $i<=$m; $i++)
{
	if($i%$a == 0)
	{
		$pro = $pro * $i;
		//$pro*=$i;
	}
}
echo $pro;
*/
	
	
	
	
	
	
	
	
	
	
	
?>
